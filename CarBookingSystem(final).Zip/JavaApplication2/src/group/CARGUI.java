package GROUP;

import java.util.ArrayList;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class CARGUI extends Application {

    @Override
    public void start(Stage primaryStage) {
        GridPane gridPane = new GridPane();
        gridPane.setAlignment(Pos.CENTER);
        gridPane.setHgap(10);
        gridPane.setVgap(10);
        gridPane.setPadding(new Insets(40));

        gridPane.setBackground(new Background(new BackgroundFill(Color.CORNSILK, null, null)));
        Text title = new Text("***** WELCOME TO CAR BOOKING SYSTEM *****");
        title.setFont(Font.font("Tahoma", FontWeight.EXTRA_BOLD, 18));
        title.setFill(Color.BROWN);
        gridPane.add(title, 0, 0, 2, 1);

        Label seatsLabel = new Label("Number of Seats:");
        TextField seatsTextField = new TextField();

        Label rnLabel = new Label("Registration Number:");
        TextField rnTextField = new TextField();

        Label plateNoLabel = new Label("Plate Number:");
        TextField plateNoTextField = new TextField();

        Label modelLabel = new Label("Model:");
        TextField modelTextField = new TextField();

        Label carTypeLabel = new Label("Car Type:");
        TextField carTypeTextField = new TextField();

        Label carColorLabel = new Label("Car Color:");
        TextField carColorTextField = new TextField();

        Label carNameLabel = new Label("Car Name:");
        TextField carNameTextField = new TextField();

        Label backUpCameraLabel = new Label("Back-up Camera:");
        TextField backUpCameraTextField = new TextField();

        Label airBagsLabel = new Label("Air Bags:");
        TextField airBagsTextField = new TextField();

        gridPane.add(seatsLabel, 0, 1);
        gridPane.add(seatsTextField, 1, 1);
        gridPane.add(rnLabel, 0, 2);
        gridPane.add(rnTextField, 1, 2);
        gridPane.add(plateNoLabel, 0, 3);
        gridPane.add(plateNoTextField, 1, 3);
        gridPane.add(modelLabel, 0, 4);
        gridPane.add(modelTextField, 1, 4);
        gridPane.add(carTypeLabel, 0, 5);
        gridPane.add(carTypeTextField, 1, 5);
        gridPane.add(carColorLabel, 0, 6);
        gridPane.add(carColorTextField, 1, 6);
        gridPane.add(carNameLabel, 0, 7);
        gridPane.add(carNameTextField, 1, 7);
        gridPane.add(backUpCameraLabel, 0, 8);
        gridPane.add(backUpCameraTextField, 1, 8);
        gridPane.add(airBagsLabel, 0, 9);
        gridPane.add(airBagsTextField, 1, 9);

        Button addButton = new Button("Add Ordinary Car");
        addButton.setTextFill(Color.BROWN);
        addButton.setFont(Font.font("FZYaoTi", FontWeight.BOLD, 15));
        gridPane.add(addButton, 1, 10);
        TextArea tArea = new TextArea();
        tArea.setEditable(false);

        gridPane.add(tArea, 1, 11, 2, 11);
        Button button = new Button("Display List");
        gridPane.add(button, 1, 22);
        button.setFont(Font.font("FZYaoTi", FontWeight.BOLD, 15));
        button.setTextFill(Color.BROWN);

        button.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                ArrayList<Car> list = Main.carList;
                String s = "";
                for (Car car : list) {
                    s += car + "\n----------------------------\n";
                }
                tArea.setText(s);
            }
        });

        addButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    int seats = Integer.parseInt(seatsTextField.getText());
                    int rn = Integer.parseInt(rnTextField.getText());
                    String plateNo = plateNoTextField.getText();
                    String model = modelTextField.getText();
                    String carType = carTypeTextField.getText();
                    String carColor = carColorTextField.getText();
                    String carName = carNameTextField.getText();
                    boolean backUpCamera = Boolean.parseBoolean(backUpCameraTextField.getText());
                    boolean airBags = Boolean.parseBoolean(airBagsTextField.getText());
                    if (plateNo.isEmpty() || model.isEmpty() || carName.isEmpty() || carType.isEmpty()) {
                        System.out.println("Fields cannot be empty.");
                    } else {
                        CarCharacteristics carCharacteristics = new CarCharacteristics(carType, carColor, carName, backUpCamera, airBags);

                        CarCharacteristics[] carCh = new CarCharacteristics[1];
                        carCh[0] = carCharacteristics;
                        OrdinaryCar ordinaryCar = new OrdinaryCar(seats, rn, plateNo, model, carCh);
                        Main.carList.add(ordinaryCar);
                        System.out.println("Ordinary Car added successfully");
                    }
                } catch (Exception e) {
                    System.out.println("Invalid value");
                }
            }
        });

        Scene scene = new Scene(gridPane, 600, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle(" Car Application");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
