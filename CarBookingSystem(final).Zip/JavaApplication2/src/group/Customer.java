
package GROUP;


public class Customer {
    
    private String Name;
    private final int ID ;
    private String PhoneNo;

    public Customer(String Name, int ID, String PhoneNo) {
        setName(Name);
        this.ID= ID;
        setPhoneNo (PhoneNo);
    }

    public Customer() {
        this(" ", 0, " ");
    }

    //setter and getter 
    
    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getID() {
        return ID;
    }

   
    

    public String getPhoneNo() {
        return PhoneNo;
    }

    public void setPhoneNo(String PhoneNo) {
        this.PhoneNo = PhoneNo;
    }

    @Override
    public String toString() {
        return  String.format (" Name: %s\n ID: %d\n PhoneNo: %s\n",Name,ID,PhoneNo) ;
    }
}
