
package GROUP;


public interface Taxable {
    
    public static final double VAT 
            = 0.15;
    
    public abstract double cmputeTax();
}
