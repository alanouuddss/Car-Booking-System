
package GROUP;


public class Trucks extends Car {
    
    private int CarringWeights;

    public Trucks(int CarringWeights, int RN, String PlateNo, String Model, CarCharacteristics[] carCh) {
        super(RN, PlateNo, Model, carCh);
        setCarringWeights(CarringWeights);
    }

    

   
    public Trucks() {
        this (0,0," "," ", null);
    }
    
   //getter and setters

    public int getCarringWeights() {
        return CarringWeights;
    }

    public void setCarringWeights(int CarringWeights) {
        this.CarringWeights = CarringWeights;
    }
    
    
    @Override
    public double TotalPrice(){
        return 500;
    }
    
    
    public void WeightBearingCapacity(){
        if (CarringWeights > 500 ){
            System.out.println("Suitable for car transportaion");
        } else
        System.out.println("Suitable for transporting goods");
    }

    @Override
    public String toString() {
        return  String.format ("%sCarringWeights: %d\n ",super.toString(),CarringWeights);
    }
}
