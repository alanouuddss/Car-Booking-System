package GROUP;

public class OrdinaryCar extends Car {

    private int seats;

    public OrdinaryCar(int seats, int ID, String PlateNo, String Model, CarCharacteristics[] carCh) {
        super(ID, PlateNo, Model, carCh);
        setSeats(seats);
    }

    public OrdinaryCar() {
        this(0, 0, " ", " ", null);
    }

    // getter and setter
    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    @Override
    public double TotalPrice() {

        return 300;
    }

    @Override
    public String toString() {
        return String.format("%sseats: %d\n ", super.toString(), seats);
    }
}
