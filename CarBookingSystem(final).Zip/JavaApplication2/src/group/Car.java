
package GROUP;


public abstract class Car  {
    
    
    private final int ID;
    private String PlateNo;
    private String Model;
    private static int TotalCars;
     private boolean available;
    private CarCharacteristics[] carCh;
    

    
    public Car(int ID,String PlateNo, String Model, CarCharacteristics[] carCh) {
        this.ID = ID;
         setPlateNo(PlateNo);
         setModel(Model);
         setCarCh(carCh);
       
      
        TotalCars++;
       
    }

 
    public Car() {
        this(0," "," ",null); 
    }

    public void setModel(String Modle) {
        this.Model = Modle;
    }

    public static void setTotalCars(int TotalCars) {
        Car.TotalCars = TotalCars;
    }

    public void setPlateNo(String PlateNo) {
        this.PlateNo = PlateNo;
    }
 
    public void setCarCh(CarCharacteristics[] carCh) {
        this.carCh = carCh;
    }

    public int getID() {
        return ID;
    }

    public String getPlateNo() {
        return PlateNo;
    }

    public String getModel() {
        return Model;
    }

    public static int getTotalCars() {
        return TotalCars;
    }

    public CarCharacteristics[] getCarCh() {
        return carCh;
    }
    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
           
  
    public abstract double TotalPrice();
    
    public final String displayCharacteristics () {
        
       String Characteristics = " ";
        
        for (CarCharacteristics c : carCh) {
           
           Characteristics += c;
           
       }
        return Characteristics;
    }

       public String carch(){
           String s="";
           
           for (CarCharacteristics c : carCh) {
               s +=c+"\n--------------------\n";
           }
           
           
           return s;
       }
        
       
    @Override
    public String toString() {
      
       return String.format(" ID : %d\nPlateNo : %s\n Model : %s\n  TotalCars : %d\nCar info:\n%s",
               ID, PlateNo, Model, TotalCars,carch());
      
    }

}
