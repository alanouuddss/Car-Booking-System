
package GROUP;


public class Taxi extends Car {

    private boolean Partition ;

    public Taxi(boolean Partition, int RN, String PlateNo, String Model, CarCharacteristics[] carCh) {
        super(RN, PlateNo, Model, carCh);
        this.Partition = Partition;
    }

   

    
    public Taxi() {
        this(false, 0," ", " ", null);  
    }
    
    //getter setter

    public boolean getPartition() {
        return Partition;
    }

    public void setPartition(boolean Partition) {
        this.Partition = Partition;
    }

    @Override
    public double TotalPrice() {
       return 100;
    }

    @Override
    public String toString() {
        return  String.format ("%sPartition: %s\n ",super.toString(),Partition);
    }
   
    }
    
    
    
    

