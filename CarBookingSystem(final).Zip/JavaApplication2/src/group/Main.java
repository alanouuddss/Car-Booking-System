package GROUP;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Main {

    static ArrayList<Car> carList = new ArrayList<>();
    static ArrayList<Booking> bookingList = new ArrayList<>();

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int choice = 0;
        fillList(carList);
        System.out.println("*** WELCOME TO CAR BOOKING SYSTEM ***");
        do {
            try {
                menu();
                choice = input.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("");
                        for (Car car : carList) {
                            System.out.println(car);
                            car.displayCharacteristics();
                            //polymorphic methods(abstract and overriden)
                            System.out.printf(" Cleaning Service Total Price : %.2f SAR.\n", car.TotalPrice());

                            //downcasting to call a specific methods
                            if (car instanceof Trucks) {
                                ((Trucks) car).WeightBearingCapacity();
                            }
                            System.out.println("***************************************************");
                        }
                        System.out.println("Total Cars: " + Car.getTotalCars());//calling static method
                        break;

                    case 2://New Booking
                        System.out.print("Enter the Reservation Number of your car: ");
                        int carID = input.nextInt();
                        Car car = null;
                        boolean found = false;
                        for (Car c : carList) {
                            if (c.getID() == carID) {
                                car = c;
                                found = true;
                                break;
                            }

                        }//end loop
                        if (!found) {
                            System.out.println("Car with this Reservation Number " + carID + " is not found.");
                            continue;
                        }

                        System.out.print(" how many days you want to leave the car?(1..30): ");
                        int days = input.nextInt();
                        if (days < 1 || days > 30) {
                            System.out.println("Invalid duration.");
                            continue;
                        }

                        System.out.println("Select Cleaning type:");
                        System.out.print("1. Interior Cleaning (35 SAR).\n"
                                + "2. External Cleaning (47 SAR).\n"
                                + "3. None.\n"
                                + ">> ");
                        int cleanType = input.nextInt();

                        CleaningService clean;
                        if (cleanType == 1) {
                            clean = new CleaningService("Interior ");
                        } else if (cleanType == 2) {
                            clean = new CleaningService("External");
                        } else {
                            clean = new CleaningService("None");;
                        }

                        //read client info
                        System.out.print("Enter your id: ");
                        int customerID = input.nextInt();
                        input.nextLine();
                        System.out.print("Enter your name: ");
                        String customerName = input.nextLine();
                        System.out.print("Enter your phone Number: ");
                        String customerPhoneNo = input.nextLine();

                        //make the object of client and booking
                        Customer customer = new Customer(customerName, customerID, customerPhoneNo);
                        //String Name, int ID, String PhoneNo
                        Booking booking = new Booking(car, days, customer, clean);
                        //Car car, int days, Customer customer, CleaningService clean
                        System.out.print("Confirm your booking? (Y/N): ");
                        char answer = input.next().charAt(0);
                        if (answer == 'y' || answer == 'Y') {
                            booking.confirm();
                            System.out.println(booking);
                            bookingList.add(booking);
                        } else {
                            System.out.println("Your booking has been cancelled!");
                        }
                        break;

                    case 3://Show Booking
                        System.out.print("Enter booking id: ");
                        int ID = input.nextInt();
                        found = false;
                        for (Booking ele : bookingList) {
                            if (ele.getID() == ID) {
                                System.out.println(ele);
                                found = true;
                            }
                        }
                        if (found == false) {
                            System.out.println("Booking with id " + ID + " is not found.");
                        }
                        break;

                    case 4://Cancel Booking
                        System.out.print("Enter booking id: ");
                        ID = input.nextInt();
                        found = false;
                        for (Booking ele : bookingList) {
                            if (ele.getID() == ID) {
                                ele.cancel();
                                System.out.println(ele);
                                found = true;
                            }
                        }
                        if (found == false) {
                            System.out.println("Booking with id " + ID + " is not found.");
                        }
                        break;

                    case 5://GUI
                        CARGUI.main(null);
                        break;

                    case 6://Read from text file
                        ReadText rt = new ReadText();
                        rt.openTextFile("bookings.txt");
                        rt.readFromFile();
                        rt.closeFile();
                        break;

                    case 7://Save/Write to text file
                        WriteText wf = new WriteText();
                        wf.openTextFile("bookings.txt");
                        if (bookingList.isEmpty()) {
                            System.out.println("No bookings yet.");
                        } else {
                            for (Booking ele : bookingList) {
                                wf.writeToFile(ele);
                            }
                        }
                        wf.closeFile();
                        System.out.println("All bookings saved to the text file bookings.txt");
                        break;

                    case 8://Exit
                        System.out.println("Thank you for using our system.\nHave a nice day.");
                        break;
                    default:
                        System.out.println("Invalid Choice!");
                }

            } catch (InputMismatchException ex) {
                System.out.println("Invalid input");
                input.nextLine();
            } catch (NullPointerException ex) {
                System.out.println(ex);
            } catch (ClassCastException ex) {
                System.out.println(ex);
            } catch (ArrayIndexOutOfBoundsException ex) {
                System.out.println(ex);
            } catch (Exception ex) {
                System.out.println(ex);
            }
        } while (choice != 8);

    }

    public static void menu() {
        System.out.println("1. Display Car Type\n"
                + "2. New Booking\n"
                + "3. Show Booking\n"
                + "4. Cancel Booking\n"
                + "5. GUI\n"
                + "6. Read From File\n"
                + "7. Save/Write Bookings.\n"
                + "8. Exit");
    }

    public static void fillList(ArrayList<Car> list) {

        CarCharacteristics Ch1 = new CarCharacteristics("Truck", "Grey", "XX", false, true);
        CarCharacteristics Ch2 = new CarCharacteristics("Taxi", "Yellow", "Elentra", false, true);
        CarCharacteristics Ch3 = new CarCharacteristics("Ordinary Car", "Silver", "CT5", true, true);
        CarCharacteristics Ch4 = new CarCharacteristics("Truck", "Red", "XX", true, false);
        CarCharacteristics Ch5 = new CarCharacteristics("Ordaniry Car ", "White", "S30", true, true);

        CarCharacteristics[] car1CarCharacteristics = {Ch3, Ch5};
        carList.add(new OrdinaryCar(5, 444, " FFF ", " Cadilac ", car1CarCharacteristics));
//int seats, int RN, String PlateNo, String Model, CarCharacteristics[] carCh
        CarCharacteristics[] car2CarCharacteristics = {Ch1, Ch4};
        carList.add(new Trucks(600, 12, " AMS ", " Mercedes ", car2CarCharacteristics));
//int CarringWeights, int RN, String PlateNo, String Model, CarCharacteristics[] carCh
        CarCharacteristics[] car3CarCharacteristics = {Ch2};
        carList.add(new Taxi(true, 712, " FAF ", " MM ", car3CarCharacteristics));
//boolean Partition, int RN, String PlateNo, String Model, CarCharacteristics[] carCh
    }

}
