package GROUP;

public class Booking implements Taxable {

    private final int ID;
    private static int count;
    private Car car;
    private int days;
    private Customer customer;
    private String status;
    private CleaningService clean;

    public Booking(Car car, int days, Customer customer, CleaningService clean) {
        this.ID = ++count;
        setCar(car);
        setDays(days);
        setCustomer(customer);
        setStatus("New");
        setClean(clean);
    }

    public Booking() {
        this(null, 0, null, null);
    }

    @Override
    public double cmputeTax() {
        return car.TotalPrice() + car.TotalPrice() * Taxable.VAT;
    }

    public final int GenerateID() {
        int min = 1;
        int max = 1000;
        int ID = (int) (Math.random() * ((max - min) + 1)) + min;
        return ID;
    }

    public final void confirm() {
        setStatus("Confirmed");
        car.setAvailable(false);
        System.out.println("Your car is confirmed \n Thank you!");
    }

    public final void cancel() {
        setStatus("Canceled");
        car.setAvailable(true);
        System.out.println("Your car is Canceled \n Sorry!");
    }

    public CleaningService getClean() {
        return clean;
    }

    public static double getVAT() {
        return VAT;
    }

//setter and getter
    public void setClean(CleaningService clean) {
        this.clean = clean;
    }

    public Car getCar() {
        return car;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public String getStatus() {
        return status;
    }

    public int getID() {
        return ID;
    }

    public int getDays() {
        return days;
    }

    public void setDays(int Days) {
        this.days = Days;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    

    @Override
    public String toString() {
       
return String.format(" ID : %d%n car : %s%n days : %d%n customer : %s%n status : %s%n clean : %s%n"
        , ID, car, days, customer, status,clean);
       
    }
}
    