
package GROUP;


public final class CarCharacteristics {

    
    
     private String CarType;
     private String CarColor;
     private String CarName;
     private boolean BackUpCamera;
     private boolean AirBags;

    public CarCharacteristics(String CarType, String CarColor, String CarName, boolean BackUpCamera, boolean AirBags) {
        setCarType(CarType);
        setCarColor(CarColor);
        setCarName(CarName);
        setBackUpCamera(BackUpCamera);
        setAirBags(AirBags);
    }
    
    public CarCharacteristics() {
        this(" ", " ", " ", false,false);
    }
    
    public void setCarType(String CarType) {
        this.CarType = CarType;
    }

    public void setCarColor(String CarColor) {
        this.CarColor = CarColor;
    }

    public void setCarName(String CarName) {
        this.CarName = CarName;
    }

   
    public void setAirBags(boolean AirBags) {
        this.AirBags = AirBags;
    }
 public void setBackUpCamera(boolean BackUpCamera) {
        this.BackUpCamera = BackUpCamera;
    }
    //all getters
    public String getCarType() {
        return CarType;
    }

    public String getCarColor() {
        return CarColor;
    }

    public String getCarName() {
        return CarName;
    }

    public boolean getAirBags() {
        return AirBags;
    }

    public boolean getBackUpCamera() {
        return BackUpCamera;
    }

    @Override
    public String toString() {
        return String.format (" CarType: %s\n CarColor: %s\n CarName: %s\n AirBags: %s\n "
                 ,CarType,CarColor,CarName,AirBags) ;
    }
 
}
