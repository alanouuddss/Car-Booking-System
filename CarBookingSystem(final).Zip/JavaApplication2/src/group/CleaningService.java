
package GROUP;


public class CleaningService implements Taxable {
    
    private String TypeOfCleaning;

    public CleaningService(String TypeOfClean) {
       setTypeOfClean(TypeOfClean);
    }
    public CleaningService() {
        this("");
    }
//setter and getter
    public String getTypeOfClean() {
        return TypeOfCleaning;
    }

    public void setTypeOfClean(String TypeOfClean) {
        this.TypeOfCleaning = TypeOfClean;
    }

    
    @Override
    public double cmputeTax() {
        
     if ("Interior Cleaning".equals(TypeOfCleaning)){
        return 200 +(200*Taxable.VAT);
        
    }else if ("External Cleaning".equals(TypeOfCleaning)){
             return 400+(400*Taxable.VAT);
             }
        else
             {
             return 0;
             }
    }
    @Override
    public String toString() {
         return String.format ("  TypeOfCleaning: %s\n",TypeOfCleaning);
    }
}
    
    
    
    
    


    
